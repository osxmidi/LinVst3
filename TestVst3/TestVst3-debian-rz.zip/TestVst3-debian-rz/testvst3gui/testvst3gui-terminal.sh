#!/bin/bash
chmod +x ./testvst3-batch
./testvst3gui
